﻿CREATE TABLE [dbo].[Users] (
    [Id]       VARCHAR (10)  NOT NULL,
    [Savedata] VARCHAR (MAX) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

