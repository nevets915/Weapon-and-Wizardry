﻿CREATE TABLE [dbo].[Users]
(
	[Id] VARCHAR(10) NOT NULL PRIMARY KEY, 
    [Savedata] VARCHAR(MAX) NULL
)
